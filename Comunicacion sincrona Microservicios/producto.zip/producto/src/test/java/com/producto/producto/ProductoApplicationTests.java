package com.producto.producto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductoApplicationTests {

	@Test
	void contextLoads() {
	}

}
