package com.example.pedido;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PedidoServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
